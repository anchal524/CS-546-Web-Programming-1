const restaurant = require("./data/restaurants");
const connection = require("./config/mongoConnection");
const {ObjectId} = require("mongodb");

async function main() {
    try {
        const wwilly = await restaurant.create(
            "The Wicked Willy",
            "Hoboken, New Jersey",
            "579-998-8975",
            "http://www.wwilly.com",
            "$$",
            ["Mexican", "Italian"],
            3.2,
            {dineIn: true, takeOut: true, delivery: false}
        ); //1.creating first restaurant
        console.log(wwilly); //2.logging it
    } catch (err) {
        console.log(err);
    }
    try {
        const benares = await restaurant.create(
            "Benares Indian Restaurant",
            "New York City, New York",
            "788-908-3426",
            "http://www.benaresindian.com",
            "$$$",
            ["Indian"],
            4,
            {dineIn: true, takeOut: false, delivery: false}
        ); //3.create second restaurant
        const allResturants = await restaurant.getAll();
        console.log(allResturants); //4.Query all restaurants, and log them all
    } catch (err) {
        console.log(err);
    }

    try {
        const thaiVilla = await restaurant.create(
            "Thai Villa",
            "Long Island, New York",
            "198-787-8452",
            "http://www.thaiVilla.com",
            "$$",
            ["Thai", "SeaFood"],
            5,
            {dineIn: true, takeOut: true, delivery: true}
        ); //5.Create the 3rd restaurant of your choice.
        console.log(thaiVilla); //6.Log the newly created 3rd restaurant
    } catch (err) {
        console.log(err);
    }

    try {
        const allResturants = await restaurant.getAll();
        const updateFirst = await restaurant.rename(
            allResturants[0]["_id"].toString(),
            "http://www.updatewwilyy.com"
        ); //7.Rename the first restaurant website
        console.log(updateFirst); //8. Log the first restaurant with the updated website.
    } catch (e) {
        console.log(e);
    }

    try {
        const allResturants = await restaurant.getAll();
        const deleteSecondResturant = await restaurant.remove(
            allResturants[1]["_id"].toString()
        ); //9.Remove the second restaurant you created.
    } catch (e) {
        console.log(e);
    }

    try {
        const allResturants = await restaurant.getAll();
        console.log(allResturants); //10.Query all restaurants, and log them all
    } catch (e) {
        console.log(e);
    }

    try {
        const badInputRest = await restaurant.create(
            " The American Diner",
            "NYC",
            348900776728, //bad parameter
            "https://www.americandiner.com",
            "$$",
            ["American"],
            2.4,
            {dineIn: true, delivery: false, dineIn: true}
        ); //11.Try to create a restaurant with bad input parameters to make sure it throws errors.
    } catch (e) {
        console.log(e);
    }

    try {
        let deleteId = "000000000000"; //bcz of timestamp rule mongo doesnt generate id like this
        const deleteUnknownResturant = await restaurant.remove(deleteId); //12.Try to remove a restaurant that does not exist to make sure it throws errors.
    } catch (e) {
        console.log(e);
    }

    try {
        const renameUnknownResturant = await restaurant.rename(
            "000000000000",
            "http://www.updatemyid.com"
        ); //13.Try to rename a restaurant that does not exist to make sure it throws errors.
    } catch (e) {
        console.log(e);
    }

    try {
        const allResturants = await restaurant.getAll();
        const deleteUnknownResturant = await restaurant.rename(
            allResturants[0]["_id"],
            "http://www.updatemyid"
        ); //14.Try to rename a restaurant passing in invalid data for the parameter to make sure it throws errors.
    } catch (e) {
        console.log(e);
    }
    try {
        const getUnknownResturant = await restaurant.get("000000000000"); //15.Try getting a restaurant by ID that does not exist to make sure it throws errors.
    } catch (e) {
        console.log(e);
    }
    const db = await connection.connectToDb();
    await connection.closeConnection();
}
main();
