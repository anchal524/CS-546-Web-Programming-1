const express = require("express");
const router = express.Router();
const session = require("express-session");

router.get("/", async (req, res) => {
    try {
        res.render("users/index", {title: "User login page"});
    } catch (e) {
        res.render("users/error", {
            httpStatusCode: "500",
            errorMessage: "Internal Server Error:Page could not be loaded",
        });
    }
});

module.exports = router;
