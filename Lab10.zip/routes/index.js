const loginRoutes = require("./login");
const signupRoutes = require("./signup");
const privateRoute = require("./private");
const loginPostRoute = require("./postlogin");
const logoutRoute = require("./logout");
const path = require("path");

const constructorMethod = (app) => {
    app.use("/logout", logoutRoute);
    app.use("/private", privateRoute);
    app.use("/login", loginPostRoute);
    app.use("/signup", signupRoutes);
    app.use("^/$", loginRoutes);
    app.use("*", (req, res) => {
        res.render("users/error", {
            httpStatusCode: "404",
            errorMessage: "page not found",
        });
    });
};

module.exports = constructorMethod;
