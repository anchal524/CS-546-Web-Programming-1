const express = require("express");
const router = express.Router();
const session = require("express-session");

router.get("/", async (req, res) => {
    try {
        res.render("users/private", {
            title: "User logged in",
            username: req.session.user.username, //use from session
        });
    } catch (e) {
        res.render("users/error", {
            title: "Error 500",
            httpStatusCode: "500",
            errorMessage: "Internal Server Error:Page could not be loaded",
        });
    }
});

module.exports = router;
