const express = require("express");
const router = express.Router();
const usersData = require("../data/user");
const mongoCollections = require("../config/mongoCollections");
const users = mongoCollections.users;

function validateStringParams(param, paramName) {
    if (!param) {
        throw `No ${paramName} entered`;
    } else if (typeof param !== "string") {
        throw ` Argument ${param} entered is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw ` No ${paramName} entered`;
    } else if (!param.trim()) {
        throw ` Empty spaces entered to ${paramName}`;
    }
}

function validateUsername(username) {
    validateStringParams(username, "username");
    let regex = /^[a-zA-Z0-9]{4,}$/;
    if (!username.match(regex)) {
        throw `username has to be alphanumeric and atleast 4 characters long`;
    }
}

function validatePassword(password) {
    validateStringParams(password, "password");
    let regex = /^\S{6,}$/;
    if (!password.match(regex)) {
        throw `password has to be valid without spaces and atleast 6 characters long`;
    }
}

async function getUserName(givenUser) {
    const usersCollection = await users();
    const usersList = await usersCollection.find({}).toArray();
    if (usersList.length === 0) {
        return false;
    }
    for (let user of usersList) {
        if (givenUser === user["username"]) {
            return true;
        }
    }
    return false;
}
router.get("/", async (req, res) => {
    try {
        res.render("users/signup", {title: "User signup page"});
    } catch (e) {
        res.render("users/error", {
            title: "Error 500",
            httpStatusCode: "500",
            errorMessage: "Internal Server Error:Page could not be loaded",
        });
    }
});

router.post("/", async (req, res) => {
    try {
        if (Object.keys(req.body).length === 0) {
            throw `No username/password entered`;
        }
        validateUsername(req.body.username);
        validatePassword(req.body.password);
        username = req.body.username.trim().toLowerCase();
        let userExists = await getUserName(username);
        if (userExists) {
            throw `Username is already in use.`;
        }
    } catch (error) {
        res.render("users/signup", {
            title: "Error 400",
            errorMessage: "Error 400 : " + error,
            hasErrors: true,
        });
        return;
    }
    try {
        req.body.username = req.body.username.trim();
        const insertUser = await usersData.createUser(
            req.body.username,
            req.body.password
        );
        if (insertUser["userInserted"]) {
            res.redirect("/");
        }
    } catch (e) {
        res.render("users/error", {
            title: "Error 500",
            httpStatusCode: "500",
            errorMessage: "Internal Server Error",
        });
    }
});

module.exports = router;
