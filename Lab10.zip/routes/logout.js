const express = require("express");
const router = express.Router();
const session = require("express-session");

router.get("/", async (req, res) => {
    req.session.destroy();
    res.render("users/logout", {title: "User logged out"});
});

module.exports = router;
