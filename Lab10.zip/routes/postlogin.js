const express = require("express");
const router = express.Router();
const session = require("express-session");
const usersData = require("../data/user");

function validateStringParams(param, paramName) {
    if (!param) {
        throw `No ${paramName} entered`;
    } else if (typeof param !== "string") {
        throw ` Argument ${param} entered is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw ` No ${paramName} entered`;
    } else if (!param.trim()) {
        throw ` Empty spaces entered to ${paramName}`;
    }
}

function validateUsername(username) {
    validateStringParams(username, "username");
    let regex = /^[a-zA-Z0-9]{4,}$/;
    if (!username.match(regex)) {
        throw ` username has to be alphanumeric and atleast 4 characters long`;
    }
}

function validatePassword(password) {
    validateStringParams(password, "password");
    let regex = /^\S{6,}$/;
    if (!password.match(regex)) {
        throw ` password has to be valid without spaces and atleast 6 characters long`;
    }
}

router.post("/", async (req, res) => {
    try {
        if (Object.keys(req.body).length === 0) {
            throw `No username/password entered`;
        }
        validateUsername(req.body.username);
        validatePassword(req.body.password);
    } catch (error) {
        res.render("users/index", {
            title: "Error 400",
            errorMessage: "Error 400 : " + error,
            hasErrors: true,
        });
        return;
    }
    try {
        req.body.username = req.body.username.trim().toLowerCase();
        const authenticatedUser = await usersData.checkUser(
            req.body.username,
            req.body.password
        );
        if (authenticatedUser["authenticated"]) {
            req.session.user = {
                username: req.body.username,
            };
            res.redirect("/private");
        }
    } catch (e) {
        res.render("users/index", {
            title: "Error 400",
            errorMessage: "Error 400 : " + e,
            hasErrors: true,
        });
    }
});

module.exports = router;
