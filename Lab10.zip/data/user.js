const mongoCollections = require("../config/mongoCollections");
const users = mongoCollections.users;
const {ObjectId} = require("mongodb");
const bcrypt = require("bcryptjs");
const saltRounds = 16;

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}
function validateUsername(username) {
    validateStringParams(username, "username");
    let regex = /^[a-zA-Z0-9]{4,}$/;
    if (!username.match(regex)) {
        throw `Error: username has to be alphanumeric and atleast 4 characters long`;
    }
}

function validatePassword(password) {
    validateStringParams(password, "password");
    let regex = /^\S{6,}$/;
    if (!password.match(regex)) {
        throw `Error: password has to be valid without spaces and atleast 6 characters long`;
    }
}

async function getUserName(givenUser) {
    const usersCollection = await users();
    const usersList = await usersCollection.find({}).toArray();
    if (usersList.length === 0) {
        return false;
    }
    for (let user of usersList) {
        if (givenUser === user["username"]) {
            return true;
        }
    }
    return false;
}
async function createUser(username, password) {
    const usersCollection = await users();
    username = username.trim().toLowerCase();
    validateUsername(username);
    let userExists = await getUserName(username);
    if (userExists) {
        throw `Username is already in use.`;
    }
    validatePassword(password);
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    let newUser = {
        username: username,
        password: hashedPassword,
    };
    const insertedDatadetails = await usersCollection.insertOne(newUser);
    if (insertedDatadetails.insertedCount === 0) {
        throw "User could not be created";
    }

    return {userInserted: true};
}

async function checkUser(username, password) {
    username = username.trim().toLowerCase();
    validateUsername(username);
    validatePassword(password);
    const usersCollection = await users();
    const userFind = await usersCollection.findOne({username: username});
    if (userFind === null) {
        throw `Either the username or password is invalid`;
    }
    hashedPassword = userFind["password"];
    comparePasswords = await bcrypt.compare(password, hashedPassword);
    if (comparePasswords) {
        return {authenticated: true};
    } else throw `Either the username or password is invalid`;
}

module.exports = {createUser, checkUser};
