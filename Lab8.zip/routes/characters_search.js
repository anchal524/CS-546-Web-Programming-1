const express = require("express");
const {character} = require("../data");
const router = express.Router();
const data = require("../data");
const characterData = data.character;

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed `;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

router.post("/", async (req, res) => {
    try {
        if (Object.keys(req.body).length === 0) {
            throw `No Search Term provided`;
        }
        validateStringParams(req.body.searchTerm, "Search Term");
    } catch (error) {
        res.render("search/error", {
            title: "Error",
            httpStatusCode: "400",
            errorMessage: error,
        });
        return;
    }
    try {
        req.body.searchTerm = req.body.searchTerm.trim();
        const characters = await characterData.searchCharData(
            req.body.searchTerm
        );
        let top20Characters = characters.data.results.slice(
            0,
            Math.min(20, characters.data.results.length)
        );
        let characterNameAndIdList = [];
        characters.data.results.forEach((character) => {
            characterNameAndIdList.push({
                id: character["id"],
                name: character["name"],
            });
        });
        res.render("search/prefix", {
            title: "Characters Found",
            characters: characterNameAndIdList,
            searchTerm: req.body.searchTerm,
        });
    } catch (e) {
        res.render("search/not_found_error", {
            title: "Error",
            httpStatusCode: "404",
            searchTerm: req.body.searchTerm,
        });
    }
});

module.exports = router;
