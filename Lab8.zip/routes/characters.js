const express = require("express");
const {character} = require("../data");
const router = express.Router();
const data = require("../data");
const characterData = data.character;

router.get("/", async (req, res) => {
    try {
        res.render("search/index", {title: "Character Finder"});
    } catch (e) {
        res.render("search/error", {
            title: "Error",
            httpStatusCode: "500",
            errorMessage: "Internal Server Error:Page could not be loaded",
        });
    }
});

module.exports = router;
