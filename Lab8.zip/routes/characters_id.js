const express = require("express");
const router = express.Router();
const data = require("../data");
const characterData = data.character;

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

router.get("/:id", async (req, res) => {
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
    } catch (e) {
        res.render("search/error", {
            title: "Error",
            httpStatusCode: "400",
            errorMessage: error,
        });
        return;
    }
    try {
        const characterIdData = await characterData.getCharData(req.params.id);
        res.render("search/character", {
            title: characterIdData.name,
            character: characterIdData,
        });
    } catch (e) {
        res.render("search/error", {
            title: "Error",
            httpStatusCode: "404",
            errorMessage: `No data found with the id ${req.params.id}`,
        });
    }
});
module.exports = router;
