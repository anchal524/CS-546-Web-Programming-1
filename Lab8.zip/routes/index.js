const characterSearchRoutes = require("./characters_search");
const characterIdRoutes = require("./characters_id");
const characterMainRoute = require("./characters");
const path = require("path");

const constructorMethod = (app) => {
    app.use("/search", characterSearchRoutes);
    app.use("/characters", characterIdRoutes);
    app.use("^/$", characterMainRoute);
    app.use("*", (req, res) => {
        res.render("search/error", {
            title: "Error",
            httpStatusCode: "404",
            errorMessage: "page not found",
        });
    });
};

module.exports = constructorMethod;
