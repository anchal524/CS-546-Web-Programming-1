const express = require("express");
const router = express.Router();
const axios = require("axios");
const md5 = require("blueimp-md5");
const publickey = "20064086eb5dea5539cf2be4e9e8f743";
const privatekey = "e9846adc932f1d910526bd99de72d895d553d5ca";
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = "https://gateway.marvel.com:443/v1/public/characters";

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

async function searchCharData(searchTerm) {
    validateStringParams(searchTerm, "Search Term");
    const url =
        baseUrl +
        "?nameStartsWith=" +
        searchTerm +
        "&ts=" +
        ts +
        "&apikey=" +
        publickey +
        "&hash=" +
        hash;
    let {data} = await axios.get(url);
    if (data.data.results.length === 0) {
        throw `No data found with the id ${searchTerm}`;
    }
    return data;
}

async function getCharData(id) {
    validateStringParams(id, "Id");
    const url =
        baseUrl +
        "/" +
        id +
        "?ts=" +
        ts +
        "&apikey=" +
        publickey +
        "&hash=" +
        hash;
    let {data} = await axios.get(url);
    if (data.data["results"].length < 1) {
        throw `No data found with id ${id}`;
    }
    data = data.data.results[0];
    let resultObj = {};
    resultObj["id"] = data["id"];
    resultObj["name"] = data["name"];
    resultObj["description"] = data["description"];
    resultObj["thumbnail"] =
        data["thumbnail"]["path"] +
        "/portrait_medium" +
        "." +
        data["thumbnail"]["extension"];
    resultObj["comics"] = [];
    data["comics"]["items"].forEach((comicElement) => {
        resultObj["comics"].push({comicsName: comicElement["name"]});
    });
    return resultObj;
}

// async function main() {
//     try {
//         const data = await searchCharData("scarlet");
//         console.log(data);
//     } catch (e) {
//         console.log(e);
//     }

//     try {
//         const data = await getCharData("1011197");
//         console.log(data);
//     } catch (e) {
//         console.log(e);
//     }
// }

// main();

module.exports = {searchCharData, getCharData};
