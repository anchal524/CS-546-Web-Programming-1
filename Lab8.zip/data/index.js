const characterData = require("./characters");

module.exports = {
    character: characterData,
};
