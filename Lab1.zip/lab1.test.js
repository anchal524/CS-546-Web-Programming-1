const lab1 = require("./lab1");

//test cases for question one
console.log(lab1.questionOne([5, 3, 10]));
//returns and outputs: { '2': true, '18': false, '93': false }
console.log(lab1.questionOne([1]));
// returns and outputs: { '6': false }
console.log(lab1.questionOne([]));
// returns and outputs: {}
console.log(lab1.questionOne());
// returns and outputs: {}
console.log(lab1.questionOne([7, -7, 7]));
// returns and outputs: { '42': false }
console.log(lab1.questionOne([-3, -5, -2]));
// returns and outputs: { '2': true, '3': true, '18': false }
console.log(lab1.questionOne([2147483647, -2147483648]));
// returns and outputs: { '4611686014132420600': false, '4611686018427388000': false }

//test cases for question two
console.log(lab1.questionTwo([3, 3, 3, 3, 3]));
//returns and outputs: [3]
console.log(lab1.questionTwo([3, "3", 3, "3", 2]));
// returns and outputs: [3,'3', 2]
console.log(lab1.questionTwo([3, "a", "b", 3, "1"]));
// returns and outputs: [3, 'a', 'b', '1']
console.log(lab1.questionTwo([]));
//returns and outputs: []
console.log(lab1.questionTwo());
//returns and outputs: []
console.log(lab1.questionTwo([1, "1", 1, "1"]));
//returns and outputs: [1,'1']
console.log(lab1.questionTwo([3, "a", "A", 3, "a"]));
// returns and outputs: [3, 'a', 'A']

//test cases for question three
console.log(lab1.questionThree(["race", "care", "foo", "oof", "cat", "act"]));
//returns and outputs: {acer: [ 'race', 'care' ],foo: [ 'foo', 'oof' ],act: [ 'cat', 'act' ]}
console.log(lab1.questionThree(["race", "care", "foo", "foo", "foo"]));
// returns and outputs: { acer: ["race", "care"] }
console.log(lab1.questionThree([]));
// returns and outputs: {}
console.log(lab1.questionThree(["foo", "foo", "foo"]));
// returns and outputs: {}
console.log(lab1.questionThree(["foo", "act", "bus"]));
// returns and outputs: {}
console.log(lab1.questionThree());
// returns and outputs: {}
console.log(lab1.questionThree(["race", "care", "Race", "RACE"]));
// returns and outputs :{ acer: [ 'race', 'care' ] }
console.log(lab1.questionThree(["race", "care", "foo", "oof", "foo"]));
// returns and outputs :{ acer: [ 'race', 'care' ],foo: [ 'foo', 'oof' ] }

//test cases for question four
console.log(lab1.questionFour(1, 3, 2));
//returns and outputs: 4
console.log(lab1.questionFour(1, 0, 2));
//returns and outputs: 4
console.log(lab1.questionFour(1, 0, 0));
//returns and outputs: 9
console.log(lab1.questionFour(2, 5, 6));
//returns and outputs: 194
console.log(lab1.questionFour(5, 6, 7));
//returns and outputs: 980
console.log(lab1.questionFour(15, 12, 20));
//returns and outputs: 155291701042341060
