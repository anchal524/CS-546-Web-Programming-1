const questionOne = function questionOne(arr) {
    let myResult = {};
    if (!arr) {
        //for no variable passed to function
        return myResult;
    }
    for (let i = 0; i < arr.length; i++) {
        let poweredNum = Math.abs(Math.pow(arr[i], 2) - 7); // calculating abs value of x*x-7
        let isPrimeNumber = true;

        //checking if this powered number is prime
        if (poweredNum == 1 || poweredNum == 0) {
            isPrimeNumber = false;
        } else {
            for (let j = 2; j < poweredNum; j++) {
                if (poweredNum % j == 0) {
                    isPrimeNumber = false;
                    break;
                }
            }
        }

        myResult[poweredNum] = isPrimeNumber;
    }
    return myResult;
};

const questionTwo = function questionTwo(arr) {
    let resultArr = [];
    if (!arr) {
        //for no variable passed to function
        return resultArr;
    }
    let arraySet = new Set(arr); //converting arr to set to remove duplicates
    resultArr = Array.from(arraySet); //converting the set to array of unique values
    return resultArr;
};

const questionThree = function questionThree(arr) {
    let resultObj = {};
    if (!arr) {
        //for no variable passed to function
        return resultObj;
    }
    let arraySet = new Set(arr);
    arr = Array.from(arraySet);

    //pushing the elements and combining their anagrams to object
    for (let i = 0; i < arr.length; i++) {
        sortedString = arr[i].split("").sort().join("");
        if (sortedString in resultObj) {
            resultObj[sortedString].push(arr[i]);
        } else {
            resultObj[sortedString] = [arr[i]];
        }
    }

    //removing the ones with count equal to one
    for (let value in resultObj) {
        if (resultObj[value].length == 1) {
            delete resultObj[value];
        }
    }
    return resultObj;
};

const questionFour = function questionFour(num1, num2, num3) {
    //inner function to calculate factorial
    function calculateFactorial(num) {
        if (num == 0 || num == 1) {
            return 1;
        }
        let factorial = 1;
        for (let i = 2; i <= num; i++) {
            factorial = factorial * i;
        }
        return factorial;
    }

    let sumFactorial = 0;
    let avgNums = (num1 + num2 + num3) / 3; //getting average of 3 input numbers
    sumFactorial =
        calculateFactorial(num1) +
        calculateFactorial(num2) +
        calculateFactorial(num3); //getting sum of the factorials of the numbers
    let result = Math.floor(sumFactorial / avgNums); //dividing sum of fact by avg and performing floor

    return result;
};

module.exports = {
    firstName: "ANCHAL",
    lastName: "BANSAL",
    studentId: "10478699",
    questionOne,
    questionTwo,
    questionThree,
    questionFour
};
