function validateObjectUtils(param) {
    if (!param) {
        throw "Error: No argument passed to the function";
    } else if (!Array.isArray(param)) {
        throw "Type Error: Argument passed is not an array";
    } else if (param.length == 0) {
        throw "Error: No element present in array";
    }
}

function validateObject(objParam) {
    if (!objParam) {
        throw "Error: No argument passed to the function";
    } else if (
        typeof objParam !== "object" ||
        Array.isArray(objParam) ||
        objParam === null
    ) {
        throw "Type Error: Argument passed is not an object";
    } else if (Object.keys(objParam).length === 0) {
        throw "Error: No element present in object";
    }
}

function isValueNumber(element) {
    if (element !== 0 && (!element || typeof element !== "number")) {
        throw "Error: Value passed to the object is not a number";
    }
}

function isFunction(func) {
    if (typeof func !== "function") {
        throw "Error: Function not passed as argument";
    }
}

function validateObjectCommonKeys(objParam) {
    if (!objParam) {
        throw "Error: No argument passed to the function";
    } else if (
        typeof objParam !== "object" ||
        Array.isArray(objParam) ||
        objParam === null
    ) {
        throw "Type Error: Argument passed is not an object";
    }
}

function computeObjects(arrObjects, funcToApply) {
    let resultObj = {};
    validateObjectUtils(arrObjects);
    isFunction(funcToApply);
    for (let i = 0; i < arrObjects.length; i++) {
        validateObject(arrObjects[i]);
        for (let obj in arrObjects[i]) {
            isValueNumber(arrObjects[i][obj]);
            if (obj in resultObj) {
                resultObj[obj] += funcToApply(arrObjects[i][obj]);
            } else {
                resultObj[obj] = funcToApply(arrObjects[i][obj]);
            }
        }
    }
    return resultObj;
}

function commonKeys(obj1, obj2) {
    function compareValues(val1, val2) {
        if (val1 === val2) {
            return true;
        }
        return false;
    }
    validateObjectCommonKeys(obj1);
    validateObjectCommonKeys(obj2);
    let commonObj = {};
    for (let keyFirst in obj1) {
        if (keyFirst in obj2) {
            if (
                typeof obj1[keyFirst] === typeof obj2[keyFirst] &&
                typeof obj1[keyFirst] === "object" &&
                !Array.isArray(obj1[keyFirst])
            ) {
                commonObj[keyFirst] = commonKeys(
                    obj1[keyFirst],
                    obj2[keyFirst]
                );
            } else {
                if (compareValues(obj1[keyFirst], obj2[keyFirst])) {
                    commonObj[keyFirst] = obj1[keyFirst];
                }
            }
        }
    }

    return commonObj;
}

function arrayFlip(arr, keyVal, obj1) {
    for (let element of arr) {
        obj1[element] = keyVal;
    }
    return obj1;
}

function flipObject(obj) {
    validateObject(obj);
    let flipDict = {};
    for (let key in obj) {
        let val = obj[key];
        if (Array.isArray(val)) {
            flipDict = arrayFlip(val, key, flipDict);
        } else if (typeof val === "object") {
            flipDict[key] = flipObject(val);
        } else {
            flipDict[val] = key;
        }
    }
    return flipDict;
}

module.exports = {
    computeObjects,
    commonKeys,
    flipObject,
};
