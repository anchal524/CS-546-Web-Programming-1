const arrayUtils = require("./arrayUtils");
const stringUtils = require("./stringUtils");
const objUtils = require("./objUtils");

//average test cases
try {
    // Should Pass
    const meanOne = arrayUtils.average([
        [1, 3],
        [2, 4, 5],
    ]);
    console.log("mean passed successfully");
} catch (e) {
    console.error("mean failed test case");
}
try {
    // Should Fail
    const meanTwo = arrayUtils.average("banana");
    console.error("mean did not error");
} catch (e) {
    console.log("mean failed successfully");
}

//mode squared test cases
try {
    // Should Pass
    const meanOne = arrayUtils.modeSquared([1, 2, 3, 3, 4]);
    console.log("modeSquared passed successfully");
} catch (e) {
    console.error("modeSquared failed test case");
}
try {
    // Should Fail
    const meanTwo = arrayUtils.modeSquared(234);
    console.error("modeSquared did not error");
} catch (e) {
    console.log("modeSquared failed successfully");
}

//median test cases
try {
    // Should Pass
    const meanOne = arrayUtils.medianElement([4, 5, 6]);
    console.log("medianElement passed successfully");
} catch (e) {
    console.error("medianElement failed test case");
}
try {
    // Should Fail
    const meanTwo = arrayUtils.medianElement(4, "h");
    console.error("medianElement did not error");
} catch (e) {
    console.log("medianElement failed successfully");
}

//merge test cases
try {
    // Should Pass
    const meanOne = arrayUtils.merge([1, 2, "a"], ["b", "A", "B", 2]);
    console.log("merge passed successfully");
} catch (e) {
    console.error("merge failed test case");
}
try {
    // Should Fail
    const meanTwo = arrayUtils.merge(null, []);
    console.error("merge did not error");
} catch (e) {
    console.log("merge failed successfully");
}

//sortString test cases
try {
    // Should Pass
    const meanOne = stringUtils.sortString("123 FOO BAR!");
    console.log("sortString passed successfully");
} catch (e) {
    console.error("sortString failed test case");
}
try {
    // Should Fail
    const meanTwo = stringUtils.sortString();
    console.error("sortString did not error");
} catch (e) {
    console.log("sortString failed successfully");
}

//replaceChar test cases
try {
    // Should Pass
    const meanOne = stringUtils.replaceChar("Dadod", 2);
    console.log("replaceChar passed successfully");
} catch (e) {
    console.error("replaceChar failed test case");
}
try {
    // Should Fail
    const meanTwo = stringUtils.replaceChar(26);
    console.error("replaceChar did not error");
} catch (e) {
    console.log("replaceChar failed successfully");
}

//mashUp test cases
try {
    // Should Pass
    const meanOne = stringUtils.mashUp("Hi", "There", "#");
    console.log("mashUp passed successfully");
} catch (e) {
    console.error("mashUp failed test case");
}
try {
    // Should Fail
    const meanTwo = stringUtils.mashUp("Hi", "@");
    console.error("mashUp did not error");
} catch (e) {
    console.log("mashUp failed successfully");
}

//computeObjects test cases

try {
    // Should Pass
    let arr = [
        {x: 2, y: 3},
        {x: 4, z: 5, a: 70},
    ];
    const meanOne = objUtils.computeObjects(arr, (x) => x * 2);
    console.log("computeObjects passed successfully");
} catch (e) {
    console.error("computeObjects failed test case");
}
try {
    // Should Fail
    const meanTwo = objUtils.computeObjects([{x: 2, y: 3}, 9]);
    console.error("computeObjects did not error");
} catch (e) {
    console.log("computeObjects failed successfully");
}

//commonKeys test cases

try {
    // Should Pass
    const first = {a: 2, b: 4};
    const second = {a: 5, b: 4};
    const meanOne = objUtils.commonKeys(first, second);
    console.log("commonKeys passed successfully");
} catch (e) {
    console.error("commonKeys failed test case");
}
try {
    // Should Fail
    const meanTwo = objUtils.commonKeys();
    console.error("commonKeys did not error");
} catch (e) {
    console.log("commonKeys failed successfully");
}

//commonKeys test cases

try {
    // Should Pass
    const meanOne = objUtils.flipObject({a: 3, b: 3});
    console.log("flipObject passed successfully");
} catch (e) {
    console.error("flipObject failed test case");
}
try {
    // Should Fail
    const meanTwo = objUtils.flipObject([88]);
    console.error("flipObject did not error");
} catch (e) {
    console.log("flipObject failed successfully");
}
