function validationStringParams(param) {
    if (!param) {
        throw "Error: No argument passed to the function";
    } else if (typeof param !== "string") {
        throw "Type Error: Argument passed is not a string";
    } else if (param.length === 0) {
        throw "Error: No element present in string";
    } else if (!param.trim()) {
        throw "Error: Empty spcaes passes to string";
    }
}

function validateIndex(idx, strLegth) {
    if (!idx) {
        throw "Error: No index passed to the function";
    }
    if (typeof idx !== "number" || !Number.isInteger(idx)) {
        throw "Type Error: Index passed is not an integer";
    }
    if (idx <= 0 || idx > strLegth - 2) {
        throw "Error: Index passed is not in the valid range";
    }
}
function sortString(str1) {
    let codeAscii = 0;
    let UpperStr = [];
    let LowerStr = [];
    let specialStr = [];
    let space = [];
    let num = [];
    validationStringParams(str1);
    for (let i = 0; i < str1.length; i++) {
        codeAscii = str1.charCodeAt(i);
        if (isUpperCaseChar(codeAscii)) {
            UpperStr.push(str1[i]);
        }
        if (isLowerCaseChar(codeAscii)) {
            LowerStr.push(str1[i]);
        }
        if (isNumber(codeAscii)) {
            num.push(str1[i]);
        }
        if (isSpecialChar(codeAscii)) {
            specialStr.push(str1[i]);
        }
        if (isSpace(codeAscii)) {
            space.push(str1[i]);
        }
    }
    UpperStr = UpperStr.sort().join("");
    LowerStr = LowerStr.sort().join("");
    num = num.sort().join("");
    specialStr = specialStr.sort().join("");
    space = space.sort().join("");
    let resultStr = "";
    if (UpperStr) {
        resultStr = resultStr.concat(UpperStr);
    }
    if (LowerStr) {
        resultStr = resultStr.concat(LowerStr);
    }
    if (specialStr) {
        resultStr = resultStr.concat(specialStr);
    }
    if (num) {
        resultStr = resultStr.concat(num);
    }

    if (space) {
        resultStr = resultStr.concat(space);
    }
    return resultStr;
}

function isLowerCaseChar(code) {
    if (code >= 97 && code <= 122) {
        return true;
    }
    return false;
}

function isNumber(element) {
    if (element >= 48 && element <= 57) {
        return true;
    }
    return false;
}

function isUpperCaseChar(element) {
    if (element >= 65 && element <= 90) {
        return true;
    }
    return false;
}

function isSpace(code) {
    if (code === 32) {
        return true;
    }
    return false;
}

function isSpecialChar(code) {
    if (
        (code >= 33 && code <= 47) ||
        (code >= 58 && code <= 64) ||
        (code >= 91 && code <= 96) ||
        (code >= 123 && code <= 126)
    ) {
        return true;
    }
    return false;
}

function replaceChar(givenStr, index) {
    validationStringParams(givenStr);
    validateIndex(index, givenStr.length);
    let charToMatch = givenStr[index];
    let beforeCharflag = true;
    let beforeChar = givenStr[index - 1];
    let afterChar = givenStr[index + 1];
    let replacedStr = "";
    for (let i = 0; i < givenStr.length; i++) {
        if (charToMatch === givenStr[i] && i !== index) {
            if (beforeCharflag) {
                replacedStr = replacedStr.concat(beforeChar);
                //givenStr[i] = beforeChar;
                beforeCharflag = false;
            } else {
                replacedStr = replacedStr.concat(afterChar);
                //givenStr[i] = afterChar;
                beforeCharflag = true;
            }
        } else {
            replacedStr = replacedStr.concat(givenStr[i]);
        }
    }
    return replacedStr;
}

function mashUp(string1, string2, char) {
    validationStringParams(string1);
    validationStringParams(string2);
    validationStringParams(char);
    if (char.length !== 1) {
        throw "Error: Character passed to Mashup is greater than length 1";
    }
    len1 = string1.length;
    len2 = string2.length;
    let mashedStr = "";
    if (len1 < len2) {
        string1 = string1.padEnd(len2, char);
    }
    if (len1 > len2) {
        string2 = string2.padEnd(len1, char);
    }
    for (let i = 0; i < string1.length; i++) {
        mashedStr = mashedStr.concat(string1[i], string2[i]);
    }
    return mashedStr;
}

module.exports = {
    sortString,
    replaceChar,
    mashUp,
};
