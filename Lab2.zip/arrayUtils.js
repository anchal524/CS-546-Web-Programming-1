function validationParams(param) {
    if (!param) {
        throw "Error: No argument passed to the function";
    } else if (!Array.isArray(param)) {
        throw "Type Error: Argument passed is not an array";
    } else if (param.length == 0) {
        throw "Error: No element present in array";
    }
}

function validateArrayParamsAsString(val) {
    if (val !== 0 && (!val || typeof val !== "number")) {
        throw `Type Error:'${val}' Argument passed in this array is not a number`;
    }
}

function average(arrays) {
    let sum = 0;
    let count = 0;
    validationParams(arrays);
    for (let i = 0; i < arrays.length; i++) {
        validationParams(arrays[i]);
        for (let j = 0; j < arrays[i].length; j++) {
            validateArrayParamsAsString(arrays[i][j]);
            sum = sum + arrays[i][j];
            count = count + 1;
        }
    }
    let averageNums = Math.round(sum / count);
    return averageNums;
}

function modeSquared(arrList) {
    function getKeyInMap(map, freqValue) {
        let modeArr = [];
        for (let key in map) {
            if (map[key] === freqValue) {
                modeArr.push(parseInt(key));
            }
        }
        return modeArr;
    }
    validationParams(arrList);
    let myMap = {};
    for (let num of arrList) {
        validateArrayParamsAsString(num);
        if (num in myMap) {
            myMap[num] += 1;
        } else {
            myMap[num] = 1;
        }
    }

    let valueArr = Object.values(myMap);
    let maxFreq = Math.max(...valueArr);
    if (maxFreq === 1) {
        return 0;
    }
    let mode = getKeyInMap(myMap, maxFreq);
    let sqMode = 0;
    for (let modeVal of mode) {
        sqMode = sqMode + Math.pow(modeVal, 2);
    }

    return sqMode;
}

function medianElement(arrayList) {
    function searchElement(element, arr) {
        for (let i = 0; i < arr.length; i++) {
            if (element === arr[i]) {
                return i;
            }
        }
    }
    function searchReversedElement(element, arr) {
        for (let i = arr.length - 1; i >= 0; i--) {
            if (element === arr[i]) {
                return i;
            }
        }
    }
    validationParams(arrayList);
    for (let i = 0; i < arrayList.length; i++) {
        validateArrayParamsAsString(arrayList[i]);
    }
    let medianResult = {};
    let index = 0;
    let unmutatedArray = Array.from(arrayList);
    arrayList = arrayList.sort(compareNumbers);
    let arrayLength = arrayList.length;
    let median = 0;
    if (arrayLength % 2 === 1) {
        median = arrayList[(arrayLength - 1) / 2];
        index = searchElement(median, unmutatedArray);
    } else {
        index = arrayLength / 2;
        median = (arrayList[index - 1] + arrayList[index]) / 2;
        if (median === arrayList[index - 1] || median === arrayList[index]) {
            index = searchElement(median, unmutatedArray);
        } else {
            let index1 = searchReversedElement(
                arrayList[index - 1],
                unmutatedArray
            );
            let index2 = searchReversedElement(
                arrayList[index],
                unmutatedArray
            );
            index = Math.max(index1, index2);
        }
    }
    medianResult[median] = index;

    return medianResult;
}

function compareNumbers(val1, val2) {
    if (val1 <= val2) {
        return -1;
    }
    return 1;
}

function merge(array1, array2) {
    validationParams(array1);
    validationParams(array2);
    let resultArray = array1.concat(array2);
    resultArray.forEach((element) => {
        if (!isAlphaNumeric(element)) {
            throw `Error: Element ${element} is not Alphanumeric`;
        }
    });
    resultArray = resultArray.sort(compare);
    return resultArray;
}

function isAlphaNumeric(element) {
    if (
        element &&
        typeof element !== "number" &&
        element.toString().length !== 1
    ) {
        return false;
    }
    if (
        !isLowerCaseLetter(element) &&
        !isUpperCaseLetter(element) &&
        !isNumeric(element)
    ) {
        return false;
    }
    return true;
}

function compare(element1, element2) {
    if (isLowerCaseLetter(element1) && isUpperCaseLetter(element2)) {
        return -1;
    }
    if (isUpperCaseLetter(element1) && isLowerCaseLetter(element2)) {
        return 1;
    }

    if (isLowerCaseLetter(element1) && isNumeric(element2)) {
        return -1;
    }
    if (isNumeric(element1) && isLowerCaseLetter(element2)) {
        return 1;
    }

    if (isUpperCaseLetter(element1) && isNumeric(element2)) {
        return -1;
    }
    if (isNumeric(element1) && isUpperCaseLetter(element2)) {
        return 1;
    }
    if (element1 < element2) {
        return -1;
    }
    if (element2 < element1) {
        return 1;
    }
    return 0;
}

function isLowerCaseLetter(element) {
    if (element >= "a" && element <= "z") {
        return true;
    }
    return false;
}

function isNumeric(element) {
    if (element !== 0 && (!element || typeof element !== "number")) {
        return false;
    }
    return true;
}

function isUpperCaseLetter(element) {
    if (element >= "A" && element <= "Z") {
        return true;
    }
    return false;
}

module.exports = {
    average,
    modeSquared,
    medianElement,
    merge,
};
