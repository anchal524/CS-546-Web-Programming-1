const dbConnection = require("../config/mongoConnection");
const data = require("../data/");
const restaurantData = data.restaurant;
const reviews = data.reviews;

async function main() {
    const db = await dbConnection.connectToDb();
    await db.dropDatabase();

    const rest1 = await restaurantData.create(
        "Saffron",
        "New York City",
        "123-456-7890",
        "http://www.saffronlounge.com",
        "$$$$",
        ["Cuban", "Italian"],
        {dineIn: true, takeOut: true, delivery: false}
    );
    const rest2 = await restaurantData.create(
        "Mango",
        "New York City",
        "324-456-6565",
        "http://www.mangolounge.com",
        "$$",
        ["Mexican", "Italian"],
        {dineIn: true, takeOut: true, delivery: true}
    );
    const wwilly = await restaurantData.create(
        "The Wicked Willy",
        "Hoboken, New Jersey",
        "579-998-8975",
        "http://www.wwilly.com",
        "$$",
        ["Mexican", "Italian"],
        {dineIn: true, takeOut: true, delivery: false}
    );
    const benares = await restaurantData.create(
        "Benares Indian Restaurant",
        "New York City, New York",
        "788-908-3426",
        "http://www.benaresindian.com",
        "$$$",
        ["Indian"],
        {dineIn: true, takeOut: false, delivery: false}
    );
    const thaiVilla = await restaurantData.create(
        "Thai Villa",
        "Long Island, New York",
        "198-787-8452",
        "http://www.thaiVilla.com",
        "$$",
        ["Thai", "SeaFood"],
        {dineIn: true, takeOut: true, delivery: true}
    );
    const americanDiner = await restaurantData.create(
        " The American Diner",
        "NYC",
        "345-999-6547",
        "https://www.americandiner.com",
        "$$",
        ["American"],
        {dineIn: true, delivery: false, takeOut: true}
    );

    const mexVilla = await restaurantData.create(
        "Mexican Villa",
        "Brooklyn, New York",
        "933-787-7512",
        "http://www.mexicanVilla.com",
        "$$$",
        ["Mexican"],
        {dineIn: true, takeOut: true, delivery: true}
    );

    const karmakafe = await restaurantData.create(
        "Karma Kafe",
        "Hoboken, New Jersey",
        "623-522-4109",
        "http://www.karmakafe.com",
        "$$",
        ["Indian"],
        {dineIn: true, takeOut: true, delivery: false}
    );

    const bistro = await restaurantData.create(
        "Bistro Excahnge Place",
        "Exchange Place, New Jersey",
        "611-233-9809",
        "http://www.bistroexplace.com",
        "$$",
        ["Mangolian"],
        {dineIn: false, takeOut: true, delivery: false}
    );

    const komegashi = await restaurantData.create(
        "Komegashi",
        "Newport, New Jersey",
        "691-303-9809",
        "http://www.komegashi.com",
        "$$$",
        ["Japanese"],
        {dineIn: true, takeOut: false, delivery: false}
    );

    const allResturants = await restaurantData.getAll();
    let newDate = new Date();
    let dateToday = (
        newDate.getMonth() +
        1 +
        "/" +
        newDate.getDate() +
        "/" +
        newDate.getFullYear()
    ).toString();
    console.log(dateToday);
    const getFirst = allResturants[0]["_id"].toString();
    const rev1_1 = await reviews.create(
        getFirst,
        "This place was great!",
        "scaredycat",
        4,
        dateToday,
        "place is great"
    );

    const rev1_2 = await reviews.create(
        getFirst,
        "This place was nice!",
        "Twisha",
        3,
        dateToday,
        "place is awesome.I loved it "
    );
    const rev2_1 = await reviews.create(
        allResturants[1]["_id"].toString(),
        "This place was bla!",
        "scaredycat",
        1,
        dateToday,
        "place is not good. Food is horrible"
    );

    const rev3_1 = await reviews.create(
        allResturants[2]["_id"].toString(),
        "This place was superb!",
        "nycFoodblogger",
        5,
        dateToday,
        "place is awesome.I loved it "
    );

    const rev3_2 = await reviews.create(
        allResturants[2]["_id"].toString(),
        "This place was wow!",
        "foodCommunityBlogger",
        4.5,
        dateToday,
        "place is awesome.I loved the service and food "
    );

    const rev3_3 = await reviews.create(
        allResturants[2]["_id"].toString(),
        "This place was good!",
        "meACAt",
        4,
        dateToday,
        "place is nice."
    );
    const rev4_1 = await reviews.create(
        allResturants[3]["_id"].toString(),
        "This place was horrible!",
        "meACAt",
        1,
        dateToday,
        "place is really shit. I would suggest eating at home"
    );
    const rev4_2 = await reviews.create(
        allResturants[3]["_id"].toString(),
        "Horrible Experience!",
        "Twisha",
        2,
        dateToday,
        "I had horrible experience. The staff is not good and the food was served cold and the food tasted so bad"
    );
    const rev5_1 = await reviews.create(
        allResturants[4]["_id"].toString(),
        "This place was good!",
        "scareedyBlogger",
        4,
        dateToday,
        "place is nice."
    );

    const rev6_1 = await reviews.create(
        allResturants[5]["_id"].toString(),
        "This place was just mind blowing!",
        "scareedyBlogger",
        5,
        dateToday,
        "The best food I had till date."
    );

    const rev6_2 = await reviews.create(
        allResturants[5]["_id"].toString(),
        "This place was awesome!",
        "foodBlogger",
        5,
        dateToday,
        "place is my go to place now."
    );
    const rev7 = await reviews.create(
        allResturants[6]["_id"].toString(),
        "This place was not good!",
        "foodBlogger",
        1,
        dateToday,
        "I won't go back here.I had a bad experience with my order."
    );
    const rev8 = await reviews.create(
        allResturants[7]["_id"].toString(),
        "This place was okay!",
        "IloveFood",
        3.5,
        dateToday,
        "place is okay.Would recommend their main course."
    );
    const rev9 = await reviews.create(
        allResturants[8]["_id"].toString(),
        "This place was good!",
        "IloveFood",
        4,
        dateToday,
        "place is nice. Do try their cocktails."
    );
    console.log("Done seeding database");

    const db1 = await dbConnection.connectToDb();
    await dbConnection.closeConnection();
}

main();
