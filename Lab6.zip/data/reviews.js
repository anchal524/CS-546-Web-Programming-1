const mongoCollections = require("../config/mongoCollections");
const restaurantsDb = mongoCollections.restaurants;
const restaurants = require("./restaurants");
const {ObjectId} = require("mongodb");

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

function validateRating(element) {
    if (element !== 0 && (!element || typeof element !== "number")) {
        throw `Error : Ratings passed is not a number`;
    }

    if (element < 0 || element > 5) {
        throw `Rating does not lie in valid range`;
    }
}

function validateDateToday(dateParams) {
    const validDateFormat = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!dateParams.match(validDateFormat)) {
        throw "date is not in valid format";
    }
    var dateParts = dateParams.split("/");
    var day = parseInt(dateParts[1], 10);
    var month = parseInt(dateParts[0], 10);
    var year = parseInt(dateParts[2], 10);
    const dateToday = new Date();
    if (
        day !== dateToday.getDate() ||
        month !== dateToday.getMonth() + 1 ||
        year !== dateToday.getFullYear()
    ) {
        throw `Given date ${dateParams} is not valid date for today`;
    }
}

async function create(
    restaurantId,
    title,
    reviewer,
    rating,
    dateOfReview,
    review
) {
    validateStringParams(restaurantId, "Id");
    restaurantId = restaurantId.trim();
    if (!ObjectId.isValid(restaurantId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    validateStringParams(title, "title");
    title = title.trim();
    validateStringParams(reviewer, "reviewer");
    reviewer = reviewer.trim();
    validateRating(rating);
    validateStringParams(dateOfReview, "dateOfReview");
    dateOfReview = dateOfReview.trim();
    validateDateToday(dateOfReview);
    validateStringParams(review, "review");
    review = review.trim();
    const collectionRestaurant = await restaurantsDb();
    const restaurantToBeReviewed = await restaurants.get(restaurantId);
    const reviewId = ObjectId();
    let newReview = {
        _id: reviewId,
        title: title,
        reviewer: reviewer,
        rating: rating,
        dateOfReview: dateOfReview,
        review: review,
    };
    overallRating = restaurantToBeReviewed["overallRating"];
    let parseId = ObjectId(restaurantId);
    const updatedInfo = await collectionRestaurant.updateOne(
        {_id: parseId},
        {$push: {reviews: newReview}}
    );
    if (updatedInfo.updatedCount === 0) {
        throw `Restaurant ${restaurantToBeReviewed["name"]} could not be updated`;
    }
    newRating = await calculateOverallRating(restaurantId);
    const updatedRating = await collectionRestaurant.updateOne(
        {_id: parseId},
        {$set: {overallRating: newRating}}
    );
    if (updatedRating.updatedCount === 0) {
        throw `Rating could not be updated for Restaurant ${restaurantToBeReviewed["name"]} `;
    }
    const updatedRestaurant = await restaurants.get(restaurantId);
    return updatedRestaurant;
}

async function getAll(restaurantId) {
    validateStringParams(restaurantId, "Restaurant Id");
    restaurantId = restaurantId.trim();
    if (!ObjectId.isValid(restaurantId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    const collectionRestaurant = await restaurantsDb();
    const restExists = await restaurants.get(restaurantId);
    let parseId = ObjectId(restaurantId);
    let reviewsList = await collectionRestaurant
        .find({_id: parseId}, {projection: {_id: 0, reviews: 1}})
        .toArray();
    if (reviewsList.length === 0) {
        return [];
    }
    const reviewsListExtracted = reviewsList["0"]["reviews"];
    for (let rest of reviewsListExtracted) {
        let id = rest["_id"];
        rest["_id"] = id.toString();
    }
    return reviewsListExtracted;
}

async function get(reviewId) {
    validateStringParams(reviewId, "Review Id");
    reviewId = reviewId.trim();
    if (!ObjectId.isValid(reviewId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    restaurantsCollection = await restaurantsDb();
    parsedReviewId = ObjectId(reviewId);
    const reviewFind = await restaurantsCollection
        .find(
            {"reviews._id": parsedReviewId},
            {projection: {_id: 0, reviews: 1}}
        )
        .toArray();
    if (reviewFind.length === 0) {
        throw `No review found with id ${reviewId}`;
    }
    const reviewsListExtracted = reviewFind["0"]["reviews"];
    for (let rest of reviewsListExtracted) {
        let id = rest["_id"].toString();
        if (id === reviewId) {
            let reviewMatch = rest;
            reviewMatch["_id"] = id;
            return reviewMatch;
        }
    }
    return [];
}

async function remove(reviewId) {
    validateStringParams(reviewId, "Review Id");
    reviewId = reviewId.trim();
    if (!ObjectId.isValid(reviewId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    restaurantsCollection = await restaurantsDb();
    parsedReviewId = ObjectId(reviewId);
    const restaurantMatched = await restaurantsCollection
        .find({"reviews._id": parsedReviewId})
        .toArray();
    if (restaurantMatched.length === 0) {
        throw `No review found with id ${reviewId}`;
    }
    let restaurantToBeDeleted = restaurantMatched[0];
    const overallRating = restaurantToBeDeleted["overallRating"];
    let idToBeRemoved = restaurantToBeDeleted["_id"];
    const updatedRest = await restaurantsCollection.updateOne(
        {_id: idToBeRemoved},
        {$pull: {reviews: {_id: parsedReviewId}}}
    );
    let output = {};
    output["reviewId"] = reviewId;
    if (updatedRest.modifiedCount > 0) {
        let newRating = await calculateOverallRating(idToBeRemoved.toString());
        const updatedRating = await restaurantsCollection.updateOne(
            {_id: idToBeRemoved},
            {$set: {overallRating: newRating}}
        );
        if (updatedRating.updatedCount === 0) {
            throw `Restaurant ${restaurantToBeDeleted["name"]} could not be updated with rating`;
        }
    } else {
        throw `Restaurant ${restaurantToBeDeleted["name"]} could not be deleted`;
    }

    output["deleted"] = true;
    return output;
}

async function calculateOverallRating(restaurantId) {
    const reviewCollection = await getAll(restaurantId);
    let ratingSum = 0;
    for (let reviewArr of reviewCollection) {
        ratingSum = ratingSum + reviewArr["rating"];
    }
    if (reviewCollection.length == 0) {
        return 0;
    }
    return ratingSum / reviewCollection.length;
}

module.exports = {create, get, getAll, remove};
