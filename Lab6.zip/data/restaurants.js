const mongoCollections = require("../config/mongoCollections");
const restaurants = mongoCollections.restaurants;
const {ObjectId} = require("mongodb");

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

function validateArray(arryparam, arrname) {
    if (!arryparam) {
        throw `Error: No ${arrname} argument passed to the function`;
    } else if (!Array.isArray(arryparam)) {
        throw `Type Error: Argument ${arrname} passed is not an array`;
    } else if (arryparam.length == 0) {
        throw `Error: No element present in array ${arrname}`;
    } else {
        for (let cuisine of arryparam) {
            validateStringParams(cuisine, "cuisine");
        }
    }
}

function validateObject(objParam) {
    if (!objParam) {
        throw "Error: Argument serviceOptions not passed to the function";
    } else if (
        typeof objParam !== "object" ||
        Array.isArray(objParam) ||
        objParam === null
    ) {
        throw "Type Error: Argument serviceOptions passed is not an object";
    } else if (Object.keys(objParam).length === 0) {
        throw "Error: No element present in object serviceOptions";
    } else if (Object.keys(objParam).length > 3) {
        throw "More than 3 options available in serviceOptions";
    }
}
function trimObjectKeys(object) {
    for (let key in object) {
        if (key !== key.trim()) {
            object[key.trim()] = object[key];
            delete object[key];
        }
    }
    return object;
}
function checkServiceOptionsValue(soptions) {
    if (!("dineIn" in soptions)) {
        throw `Error : dineIn not available as argument in serviceOptions`;
    }
    if (!("takeOut" in soptions)) {
        throw `Error : takeOut not available as argument in serviceOptions`;
    }
    if (!("delivery" in soptions)) {
        throw `Error : delivery not available as argument in serviceOptions`;
    }

    if (typeof soptions["dineIn"] !== "boolean") {
        throw `Error: dineIn value is not a boolean type`;
    }
    if (typeof soptions["takeOut"] !== "boolean") {
        throw `Error: takeOut value is not a boolean type`;
    }
    if (typeof soptions["delivery"] !== "boolean") {
        throw `Error: delivery value is not a boolean type`;
    }
}

function validatePhone(phoneNumber) {
    const validPhone = /^\d{3}-\d{3}-\d{4}$/;
    phoneNumber = phoneNumber.trim();
    if (!phoneNumber.match(validPhone)) {
        throw `Error: ${phoneNumber} is not a valid phone number`;
    }
}

function validateWebsite(websiteLink) {
    const validLink = /^http(s)?:\/\/www\..{5,}\.com$/;
    websiteLink = websiteLink.trim().toLowerCase();
    if (!websiteLink.match(validLink)) {
        throw `Error: ${websiteLink} is not a valid web site link`;
    }
}
function validatePriceRange(priceRange) {
    if (priceRange.length < 0 || priceRange.length > 4) {
        throw `Error: Price Range is not in valid range`;
    } else {
        for (let priceChar of priceRange) {
            if (priceChar !== "$") {
                throw ` Error : Price Range has invalid characters`;
            }
        }
    }
}

async function get(searchId) {
    validateStringParams(searchId, "Id");
    searchId = searchId.trim();
    if (!ObjectId.isValid(searchId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    let parseId = ObjectId(searchId);
    const collectionRestaurant = await restaurants();
    const restaurantFound = await collectionRestaurant.findOne({_id: parseId});
    if (restaurantFound === null) {
        throw `No restaurant found with the id ${searchId}`;
    }
    restaurantFound["_id"] = searchId;
    let reviewRest = restaurantFound["reviews"];
    if (reviewRest.length > 0) {
        for (let rev of reviewRest) {
            let id = rev["_id"];
            rev["_id"] = id.toString();
        }
    }
    return restaurantFound;
}

async function create(
    name,
    location,
    phoneNumber,
    website,
    priceRange,
    cuisines,
    serviceOptions
) {
    validateStringParams(name, "name");
    name = name.trim();
    validateStringParams(location, "location");
    location = location.trim();
    validateStringParams(phoneNumber, "phone number");
    phoneNumber = phoneNumber.trim();
    validatePhone(phoneNumber);
    validateStringParams(website, "website");
    website = website.trim().toLowerCase();
    validateWebsite(website);
    validateStringParams(priceRange, "price range");
    priceRange = priceRange.trim();
    validatePriceRange(priceRange);
    validateArray(cuisines, "cuisines");
    cuisines = cuisines.map((c) => c.trim());
    validateObject(serviceOptions);
    serviceOptions = trimObjectKeys(serviceOptions);
    checkServiceOptionsValue(serviceOptions);

    const collectionRestaurant = await restaurants();
    let newRestaurant = {
        name: name,
        location: location,
        phoneNumber: phoneNumber,
        website: website,
        priceRange: priceRange,
        cuisines: cuisines,
        overallRating: 0, //0 rating
        serviceOptions: serviceOptions,
        reviews: [], //empty reviews
    };
    const allRestaurantList = await getAllRest();
    for (let rest in allRestaurantList) {
        if (
            allRestaurantList[rest]["name"] === name &&
            allRestaurantList[rest]["phoneNumber"] === phoneNumber &&
            allRestaurantList[rest]["location"] === location
        ) {
            throw `Error: Restaurant already exists`;
        }
    }
    const insertedDatadetails = await collectionRestaurant.insertOne(
        newRestaurant
    );
    if (insertedDatadetails.insertedCount === 0) {
        throw "Restaurant could not be inserted";
    }

    const newRestaurantId = insertedDatadetails.insertedId.toString();

    const restaurantDetails = await get(newRestaurantId);
    return restaurantDetails;
}

async function getAllRest() {
    let len = arguments.length;
    if (len > 0) {
        throw `Error: getAll does not accept arguments`;
    }
    const collectionRestaurant = await restaurants();

    const restaurantList = await collectionRestaurant.find({}).toArray();
    if (restaurantList.length === 0) {
        return [];
    }
    for (let rest of restaurantList) {
        let id = rest["_id"];
        rest["_id"] = id.toString();
    }
    return restaurantList;
}

async function getAll() {
    let len = arguments.length;
    if (len > 0) {
        throw `Error: getAll does not accept arguments`;
    }
    const collectionRestaurant = await restaurants();

    const restaurantList = await collectionRestaurant
        .find({}, {projection: {_id: 1, name: 1}})
        .toArray();
    if (restaurantList.length === 0) {
        return [];
    }
    for (let rest of restaurantList) {
        let id = rest["_id"];
        rest["_id"] = id.toString();
    }
    return restaurantList;
}

async function remove(givenId) {
    validateStringParams(givenId, "Id");
    givenId = givenId.trim();
    if (!ObjectId.isValid(givenId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    const collectionRestaurant = await restaurants();
    const restaurantToBeDeleted = await get(givenId);
    let parseId = ObjectId(givenId);
    const deletedRestaurant = await collectionRestaurant.deleteOne({
        _id: parseId,
    });
    let output = {};
    output["restaurantId"] = givenId;
    if (deletedRestaurant.deletedCount === 0) {
        throw `The restaurant with id ${givenId} could not be deleted`;
    } else {
        output["deleted"] = true;
        return output;
    }
}

async function update(
    givenId,
    name,
    location,
    phoneNumber,
    website,
    priceRange,
    cuisines,
    serviceOptions
) {
    validateStringParams(givenId, "Id");
    givenId = givenId.trim();
    if (!ObjectId.isValid(givenId)) {
        throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
    }
    validateStringParams(name, "name");
    name = name.trim();
    validateStringParams(location, "location");
    location = location.trim();
    validateStringParams(phoneNumber, "phone number");
    phoneNumber = phoneNumber.trim();
    validatePhone(phoneNumber);
    validateStringParams(website, "website");
    website = website.trim().toLowerCase();
    validateWebsite(website);
    validateStringParams(priceRange, "price range");
    priceRange = priceRange.trim();
    validatePriceRange(priceRange);
    validateArray(cuisines, "cuisines");
    cuisines = cuisines.map((c) => c.trim());
    validateObject(serviceOptions);
    serviceOptions = trimObjectKeys(serviceOptions);
    checkServiceOptionsValue(serviceOptions);
    const collectionRestaurant = await restaurants();
    const restaurantToBeUpdated = await get(givenId);
    let parseId = ObjectId(givenId);
    const updateRestaurantInfo = {
        name: name,
        location: location,
        phoneNumber: phoneNumber,
        website: website,
        priceRange: priceRange,
        cuisines: cuisines,
        serviceOptions: serviceOptions,
    };
    const updatedInfo = await collectionRestaurant.updateOne(
        {_id: parseId},
        {$set: updateRestaurantInfo}
    );

    if (updatedInfo.updatedCount === 0) {
        throw `Restaurant ${restaurantToBeUpdated["name"]} could not be updated`;
    }
    return await get(givenId);
}

module.exports = {create, get, getAll, remove, update};
