const express = require("express");
const router = express.Router();
const data = require("../data");
const reviewData = data.reviews;
const restaurantData = data.restaurant;
const {ObjectId} = require("mongodb");

function validateStringParams(param, paramName) {
    if (!param) {
        throw ` No ${paramName} passed in the request`;
    } else if (typeof param !== "string") {
        throw ` Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw ` No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw ` Empty spaces passed to string ${paramName}`;
    }
}

function validateRating(element) {
    if (element !== 0 && (!element || typeof element !== "number")) {
        throw `Ratings passed is not a number`;
    }

    if (element < 0 || element > 5) {
        throw `Rating does not lie in valid range`;
    }
}

function validateDateToday(dateParams) {
    const validDateFormat = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!dateParams.match(validDateFormat)) {
        throw "date is not in valid format";
    }
    var dateParts = dateParams.split("/");
    var day = parseInt(dateParts[1], 10);
    var month = parseInt(dateParts[0], 10);
    var year = parseInt(dateParts[2], 10);
    const dateToday = new Date();
    if (
        day !== dateToday.getDate() ||
        month !== dateToday.getMonth() + 1 ||
        year !== dateToday.getFullYear()
    ) {
        throw `Given date ${dateParams} is not valid date for today`;
    }
}

router.get("/:id", async (req, res) => {
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
        if (!ObjectId.isValid(req.params.id)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const restData = await restaurantData.get(req.params.id);
    } catch (e) {
        res.status(404).json({error: e});
        return;
    }
    try {
        const reviewsDataForRestaurant = await reviewData.getAll(req.params.id);
        if (reviewsDataForRestaurant.length === 0) {
            res.status(404).json(reviewsDataForRestaurant);
            return;
        }
        res.status(200).json(reviewsDataForRestaurant);
    } catch (e) {
        res.status(500).json({error: "Could not be found"});
    }
});

router.post("/:id", async (req, res) => {
    let restId = req.params.id;
    let reviewToBeCreated = req.body;
    try {
        validateStringParams(restId, "Id");
        restId = restId.trim();
        if (!ObjectId.isValid(restId)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
        if (Object.keys(req.body).length === 0) {
            throw `You must provide data to create review`;
        }
        validateStringParams(reviewToBeCreated.title, "title");
        reviewToBeCreated.title = reviewToBeCreated.title.trim();
        validateStringParams(reviewToBeCreated.reviewer, "reviewer");
        reviewToBeCreated.reviewer = reviewToBeCreated.reviewer.trim();
        validateRating(reviewToBeCreated.rating);
        validateStringParams(reviewToBeCreated.dateOfReview, "dateOfReview");
        reviewToBeCreated.dateOfReview = reviewToBeCreated.dateOfReview.trim();
        validateDateToday(reviewToBeCreated.dateOfReview);
        validateStringParams(reviewToBeCreated.review, "review");
        reviewToBeCreated.review = reviewToBeCreated.review.trim();
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const restData = await restaurantData.get(restId);
    } catch (e) {
        res.status(404).json({error: e});
        return;
    }
    try {
        const newReview = await reviewData.create(
            restId,
            reviewToBeCreated.title,
            reviewToBeCreated.reviewer,
            reviewToBeCreated.rating,
            reviewToBeCreated.dateOfReview,
            reviewToBeCreated.review
        );
        res.status(200).json(newReview);
    } catch (e) {
        res.status(500).json({error: "Review could not be created"});
    }
});

router.get("/review/:id", async (req, res) => {
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
        if (!ObjectId.isValid(req.params.id)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const reviewsData = await reviewData.get(req.params.id);
        res.status(200).json(reviewsData);
    } catch (e) {
        res.status(404).json({error: "Review not found"});
    }
});

router.delete("/:id", async (req, res) => {
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
        if (!ObjectId.isValid(req.params.id)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const reviewsData = await reviewData.get(req.params.id);
    } catch (e) {
        res.status(404).json({error: "Review id not found"});
        return;
    }
    try {
        const reviewToBeDeleted = await reviewData.remove(req.params.id);
        res.status(200).json(reviewToBeDeleted);
    } catch (e) {
        res.status(500).json({error: e});
    }
});
module.exports = router;
