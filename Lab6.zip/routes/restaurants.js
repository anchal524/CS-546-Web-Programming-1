const express = require("express");
const router = express.Router();
const data = require("../data");
const restaurantData = data.restaurant;
const {ObjectId} = require("mongodb");

function validateStringParams(param, paramName) {
    if (!param) {
        throw `No ${paramName} passed in the request`;
    } else if (typeof param !== "string") {
        throw `Argument ${param} passed is not a string ${paramName}`;
    } else if (param.length === 0) {
        throw `No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Empty spaces passed to string ${paramName}`;
    }
}

function validateArray(arryparam, arrname) {
    if (!arryparam) {
        throw ` No ${arrname} argument passed in the request`;
    } else if (!Array.isArray(arryparam)) {
        throw `Argument ${arrname} passed is not an array`;
    } else if (arryparam.length == 0) {
        throw `No element present in array ${arrname}`;
    } else {
        for (let cuisine of arryparam) {
            validateStringParams(cuisine, "cuisine");
        }
    }
}

function validateObject(objParam) {
    if (!objParam) {
        throw "Argument serviceOptions not passed in the request";
    } else if (
        typeof objParam !== "object" ||
        Array.isArray(objParam) ||
        objParam === null
    ) {
        throw "Argument serviceOptions passed is not an object";
    } else if (Object.keys(objParam).length === 0) {
        throw " No element present in object serviceOptions";
    } else if (Object.keys(objParam).length > 3) {
        throw "More than 3 options available in serviceOptions";
    }
}

function trimObjectKeys(object) {
    for (let key in object) {
        if (key !== key.trim()) {
            object[key.trim()] = object[key];
            delete object[key];
        }
    }
    return object;
}

function checkServiceOptionsValue(soptions) {
    if (!("dineIn" in soptions)) {
        throw `dineIn not available as argument in serviceOptions`;
    }
    if (!("takeOut" in soptions)) {
        throw `takeOut not available as argument in serviceOptions`;
    }
    if (!("delivery" in soptions)) {
        throw `delivery not available as argument in serviceOptions`;
    }

    if (typeof soptions["dineIn"] !== "boolean") {
        throw `dineIn value is not a boolean type`;
    }
    if (typeof soptions["takeOut"] !== "boolean") {
        throw `takeOut value is not a boolean type`;
    }
    if (typeof soptions["delivery"] !== "boolean") {
        throw `delivery value is not a boolean type`;
    }
}

function validatePhone(phoneNumber) {
    const validPhone = /^\d{3}-\d{3}-\d{4}$/;
    phoneNumber = phoneNumber.trim();
    if (!phoneNumber.match(validPhone)) {
        throw `${phoneNumber} is not a valid phone number`;
    }
}

function validateWebsite(websiteLink) {
    const validLink = /^http(s)?:\/\/www\..{5,}\.com$/;
    websiteLink = websiteLink.trim().toLowerCase();
    if (!websiteLink.match(validLink)) {
        throw `${websiteLink} is not a valid web site link`;
    }
}
function validatePriceRange(priceRange) {
    if (priceRange.length < 0 || priceRange.length > 4) {
        throw `Price Range is not in valid range`;
    } else {
        for (let priceChar of priceRange) {
            if (priceChar !== "$") {
                throw ` Price Range has invalid characters`;
            }
        }
    }
}

router.get("/:id", async (req, res) => {
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
        if (!ObjectId.isValid(req.params.id)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const restaurantById = await restaurantData.get(req.params.id);
        res.status(200).json(restaurantById);
    } catch (e) {
        res.status(404).json({error: e});
    }
});

router.get("/", async (req, res) => {
    try {
        const restaurantList = await restaurantData.getAll();
        res.status(200).json(restaurantList);
    } catch (e) {
        res.status(500).json({error: "Restaurant data not available"});
    }
});

router.post("/", async (req, res) => {
    let restaurantToBeCreated = req.body;
    try {
        if (Object.keys(req.body).length === 0) {
            throw `You must provide data to create restaurant`;
        }
        validateStringParams(restaurantToBeCreated.name, "name");
        restaurantToBeCreated.name = restaurantToBeCreated.name.trim();
        validateStringParams(restaurantToBeCreated.location, "location");
        restaurantToBeCreated.location = restaurantToBeCreated.location.trim();
        validateStringParams(restaurantToBeCreated.phoneNumber, "phone number");
        restaurantToBeCreated.phoneNumber =
            restaurantToBeCreated.phoneNumber.trim();
        validatePhone(restaurantToBeCreated.phoneNumber);
        validateStringParams(restaurantToBeCreated.website, "website");
        restaurantToBeCreated.website = restaurantToBeCreated.website
            .trim()
            .toLowerCase();
        validateWebsite(restaurantToBeCreated.website);
        validateStringParams(restaurantToBeCreated.priceRange, "price range");
        restaurantToBeCreated.priceRange =
            restaurantToBeCreated.priceRange.trim();
        validatePriceRange(restaurantToBeCreated.priceRange);
        validateArray(restaurantToBeCreated.cuisines, "cuisines");
        restaurantToBeCreated.cuisines = restaurantToBeCreated.cuisines.map(
            (c) => c.trim()
        );
        validateObject(restaurantToBeCreated.serviceOptions);
        restaurantToBeCreated.serviceOptions = trimObjectKeys(
            restaurantToBeCreated.serviceOptions
        );
        checkServiceOptionsValue(restaurantToBeCreated.serviceOptions);
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const newRestaurant = await restaurantData.create(
            restaurantToBeCreated.name,
            restaurantToBeCreated.location,
            restaurantToBeCreated.phoneNumber,
            restaurantToBeCreated.website,
            restaurantToBeCreated.priceRange,
            restaurantToBeCreated.cuisines,
            restaurantToBeCreated.serviceOptions
        );
        res.status(200).json(newRestaurant);
    } catch (e) {
        res.status(500).json({error: "New restaurant could not be created"});
    }
});

router.put("/:id", async (req, res) => {
    let restaurantById = req.params.id;
    const restaurantToBeUpdated = req.body;
    try {
        validateStringParams(restaurantById, "Id");
        restaurantById = restaurantById.trim();
        if (!ObjectId.isValid(restaurantById)) {
            throw `Error : Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
        if (Object.keys(req.body).length === 0) {
            throw `You must provide data to update restaurant`;
        }
        validateStringParams(restaurantToBeUpdated.name, "name");
        restaurantToBeUpdated.name = restaurantToBeUpdated.name.trim();
        validateStringParams(restaurantToBeUpdated.location, "location");
        restaurantToBeUpdated.location = restaurantToBeUpdated.location.trim();
        validateStringParams(restaurantToBeUpdated.phoneNumber, "phone number");
        restaurantToBeUpdated.phoneNumber =
            restaurantToBeUpdated.phoneNumber.trim();
        validatePhone(restaurantToBeUpdated.phoneNumber);
        validateStringParams(restaurantToBeUpdated.website, "website");
        restaurantToBeUpdated.website = restaurantToBeUpdated.website
            .trim()
            .toLowerCase();
        validateWebsite(restaurantToBeUpdated.website);
        validateStringParams(restaurantToBeUpdated.priceRange, "price range");
        restaurantToBeUpdated.priceRange =
            restaurantToBeUpdated.priceRange.trim();
        validatePriceRange(restaurantToBeUpdated.priceRange);
        validateArray(restaurantToBeUpdated.cuisines, "cuisines");
        restaurantToBeUpdated.cuisines = restaurantToBeUpdated.cuisines.map(
            (c) => c.trim()
        );
        validateObject(restaurantToBeUpdated.serviceOptions);
        restaurantToBeUpdated.serviceOptions = trimObjectKeys(
            restaurantToBeUpdated.serviceOptions
        );
        checkServiceOptionsValue(restaurantToBeUpdated.serviceOptions);
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const restData = await restaurantData.get(restaurantById);
    } catch (e) {
        res.status(404).json({error: e});
        return;
    }
    try {
        const updateRestaurant = await restaurantData.update(
            restaurantById,
            restaurantToBeUpdated.name,
            restaurantToBeUpdated.location,
            restaurantToBeUpdated.phoneNumber,
            restaurantToBeUpdated.website,
            restaurantToBeUpdated.priceRange,
            restaurantToBeUpdated.cuisines,
            restaurantToBeUpdated.serviceOptions
        );
        res.status(200).json(updateRestaurant);
    } catch (e) {
        res.status(500).json({error: "Restaurant could not be updated"});
    }
});

router.delete("/:id", async (req, res) => {
    const restaurantById = req.params.id;
    try {
        validateStringParams(req.params.id, "Id");
        req.params.id = req.params.id.trim();
        if (!ObjectId.isValid(req.params.id)) {
            throw `Id passed in must be a Buffer or string of 12 bytes or a string of 24 hex characters`;
        }
    } catch (e) {
        res.status(400).json({error: e});
        return;
    }
    try {
        const restData = await restaurantData.get(restaurantById);
    } catch (e) {
        res.status(404).json({error: e});
        return;
    }
    try {
        const deleteRestaurant = await restaurantData.remove(restaurantById);
        res.status(200).json(deleteRestaurant);
    } catch (e) {
        res.status(500).json({error: "Restaurant could not be deleted"});
    }
});
module.exports = router;
