const axios = require("axios");

async function getStocksData() {
    let {data} = await axios.get(
        "https://gist.githubusercontent.com/graffixnyc/8c363d85e61863ac044097c0d199dbcc/raw/7d79752a9342ac97e4953bce23db0388a39642bf/stocks.json"
    );

    return data;
}

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

async function getStockById(searchId) {
    validateStringParams(searchId, "Stock Id");
    const stockData = await getStocksData();
    //searchId = searchId.trim();
    searchId = searchId.replace(/\s+$/, ""); //trimming just the trailing spaces
    for (let stock of stockData) {
        if (stock["id"] === searchId) {
            return stock;
        }
    }
    throw `Not Found Error : Id ${searchId} not found in stock data`;
}

module.exports = {getStocksData, getStockById};
