const axios = require("axios");

async function getPeopleData() {
    let {data} = await axios.get(
        "https://gist.githubusercontent.com/graffixnyc/a1196cbf008e85a8e808dc60d4db7261/raw/9fd0d1a4d7846b19e52ab3551339c5b0b37cac71/people.json"
    );

    return data;
}

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

async function getPersonById(searchId) {
    validateStringParams(searchId, "Id");
    const peopleData = await getPeopleData();
    //searchId = searchId.trim();
    searchId = searchId.replace(/\s+$/, "");
    for (let pd of peopleData) {
        if (pd["id"] === searchId) {
            return pd;
        }
    }
    throw `Person not Found Error : Id ${searchId} not found in people data`;
}

module.exports = {
    getPeopleData,
    getPersonById,
};
