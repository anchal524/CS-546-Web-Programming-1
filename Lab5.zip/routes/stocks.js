const express = require("express");
const router = express.Router();
const data = require("../data");
const stocksData = data.stocks;

router.get("/:id", async (req, res) => {
    try {
        const stocksList = await stocksData.getStockById(req.params.id);
        res.json(stocksList);
    } catch (e) {
        res.status(404).json({
            message: `Stock with id ${req.params.id} not found in the data`,
        });
    }
});

router.get("/", async (req, res) => {
    try {
        const stocksList = await stocksData.getStocksData();
        res.json(stocksList);
    } catch (e) {
        res.status(500).json({message: "Stocks data not available"});
    }
});

router.post("/", async (req, res) => {
    res.status(501).json({message: "Post not supported"});
});

router.delete("/", async (req, res) => {
    res.status(501).json({message: "Delete not supported"});
});

module.exports = router;
