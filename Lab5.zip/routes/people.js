const express = require("express");
const router = express.Router();
const data = require("../data");
const peopleData = data.people;

router.get("/:id", async (req, res) => {
    try {
        const peopleList = await peopleData.getPersonById(req.params.id);
        res.json(peopleList);
    } catch (e) {
        res.status(404).json({
            message: `Person with id ${req.params.id} not found in the data`,
        });
    }
});

router.get("/", async (req, res) => {
    try {
        const peopleList = await peopleData.getPeopleData();
        res.json(peopleList);
    } catch (e) {
        res.status(500).json({message: "Person data not available"});
    }
});

router.post("/", async (req, res) => {
    res.status(501).json({message: "Post not supported"});
});

router.delete("/", async (req, res) => {
    res.status(501).json({message: "Delete not supported"});
});

module.exports = router;
