const axios = require("axios");

async function getPeopleData() {
    let {data} = await axios.get(
        "https://gist.githubusercontent.com/graffixnyc/a1196cbf008e85a8e808dc60d4db7261/raw/9fd0d1a4d7846b19e52ab3551339c5b0b37cac71/people.json"
    );

    return data;
}

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}

function validateDateParams(val, pname) {
    if (typeof val === "string") {
        val = val.trim();
        let regex = /^\d+(\.0+){0,1}$/;
        if (!val.match(regex)) {
            throw `Error: ${val} is not a valid number`;
        }
    } else {
        if (val !== 0 && !val) {
            throw `Error: No ${pname} passed to the function`;
        }
        if (typeof val !== "number") {
            throw `Type Error:'${val}' ${pname} passed in this function is not a number`;
        }
        if (val === 0) {
            throw `Zero Error: 0 is not a valid ${pname}`;
        }
        if (!Number.isInteger(val)) {
            throw `Error: ${val} is not an integer`;
        }
    }
}

function validateMonth(month) {
    if (month <= 0) {
        throw `Error: ${month} is not a valid month since it is less than or equal to zero`;
    }
    if (month >= 13) {
        throw `Error: ${month} is not a valid month since it is greater than 12`;
    }
}
function validateDay(day, month) {
    let monthlist = {
        1: 31,
        2: 28,
        3: 31,
        4: 30,
        5: 31,
        6: 30,
        7: 31,
        8: 31,
        9: 30,
        10: 31,
        11: 30,
        12: 31,
    };

    let monthName = {
        1: "Jan",
        2: "Feb",
        3: "Mar",
        4: "Apr",
        5: "May",
        6: "June",
        7: "July",
        8: "Aug",
        9: "Sep",
        10: "Oct",
        11: "Nov",
        12: "Dec",
    };
    if (monthlist[month] < day || day <= 0) {
        throw `Error : ${day} is not valid date in ${monthName[month]}`;
    }
}

async function getPersonById(searchId) {
    validateStringParams(searchId, "Id");
    const peopleData = await getPeopleData();
    searchId = searchId.trim();
    for (let pd of peopleData) {
        if (pd["id"] === searchId) {
            return pd;
        }
    }
    throw `Person not Found Error : Id ${searchId} not found in people data`;
}

async function sameStreet(givenStreetName, givenStreetSuffix) {
    validateStringParams(givenStreetName, "Street Name");
    validateStringParams(givenStreetSuffix, "Street Suffix");
    let resultSameStreet = [];
    const peopleData = await getPeopleData();
    givenStreetName = givenStreetName.trim().toLowerCase();
    givenStreetSuffix = givenStreetSuffix.trim().toLowerCase();
    for (let pd of peopleData) {
        let homeAddress = pd["address"]["home"];
        let workAddress = pd["address"]["work"];
        if (
            (homeAddress["street_name"].toLowerCase() === givenStreetName ||
                workAddress["street_name"].toLowerCase() === givenStreetName) &&
            (homeAddress["street_suffix"].toLowerCase() === givenStreetSuffix ||
                workAddress["street_suffix"].toLowerCase() ===
                    givenStreetSuffix)
        ) {
            resultSameStreet.push(pd);
        }
    }
    if (resultSameStreet.length > 1) {
        return resultSameStreet;
    } else {
        throw `Error : No 2 or more than 2 people stay or work at ${givenStreetName} ${givenStreetSuffix}`;
    }
}

async function manipulateSsn() {
    let len = arguments.length;
    if (len > 0) {
        throw `Error: manipulateSsn does not accept arguments`;
    }
    const peopleData = await getPeopleData();
    let resultSsn = {};
    let ssnMap = {};
    let ssnNameMap = {};
    let ssnList = [];
    let count = 0;
    let sumSsn = 0;
    for (let pd of peopleData) {
        let ssn = pd["ssn"].trim().replace(/-/g, "");
        ssn = parseInt(sortDigits(ssn)); //sort ssn
        ssnList.push(ssn); //list of all sorted SSN's
        count = count + 1;
        sumSsn = sumSsn + ssn;
        ssnMap[pd["ssn"]] = ssn; //mapping original SSN to sorted one
        ssnNameMap[pd["ssn"]] = [pd["first_name"], pd["last_name"]]; //mapping original SSN to fname and lname
    }
    let average = Math.floor(sumSsn / count); //average of all ssn's
    ssnList.sort(compareNumbers); //sort list of SSN's
    let highestSsn = ssnList[ssnList.length - 1]; //highest SSn
    let lowestSsn = ssnList[0]; //lowest SSN
    let originalHighestSsn = getvaluefromObject(ssnMap, highestSsn);
    let highestSsnpersonfName = ssnNameMap[originalHighestSsn][0];
    let highestSsnpersonlName = ssnNameMap[originalHighestSsn][1];
    let originalLowestSsn = getvaluefromObject(ssnMap, lowestSsn);
    let lowestSsnpersonfName = ssnNameMap[originalLowestSsn][0];
    let lowestSsnpersonlName = ssnNameMap[originalLowestSsn][1];
    resultSsn["highest"] = {
        firstName: highestSsnpersonfName,
        lastName: highestSsnpersonlName,
    };
    resultSsn["lowest"] = {
        firstName: lowestSsnpersonfName,
        lastName: lowestSsnpersonlName,
    };
    resultSsn["average"] = average;
    return resultSsn;
}

function sortDigits(ssnVal) {
    let ssnDigit = [];
    for (let x of ssnVal) {
        ssnDigit.push(x);
    }
    ssnVal = ssnDigit.sort(compareNumbers).join("");
    return ssnVal;
}

function compareNumbers(val1, val2) {
    if (val1 <= val2) {
        return -1;
    }
    return 1;
}

function getvaluefromObject(ssnObj, targetSsn) {
    return Object.keys(ssnObj).find((key) => ssnObj[key] === targetSsn);
}

async function sameBirthday(givenMonth, givenDay) {
    let resultSameBirthDay = [];
    validateDateParams(givenMonth, "month");
    validateDateParams(givenDay, "day");
    let integerMonth = parseInt(givenMonth);
    let integerDay = parseInt(givenDay);
    validateMonth(integerMonth);
    validateDay(integerDay, integerMonth);
    const peopleData = await getPeopleData();
    for (let pd of peopleData) {
        let month = parseInt(
            pd["date_of_birth"].split("/")[0].replace(/^0+/, "")
        );
        let day = parseInt(
            pd["date_of_birth"].split("/")[1].replace(/^0+/, "")
        );
        if (integerMonth === month && day === integerDay) {
            resultSameBirthDay.push(pd["first_name"] + " " + pd["last_name"]);
        }
    }
    if (resultSameBirthDay.length > 0) {
        return resultSameBirthDay;
    } else {
        throw ` There are no people with birthday as month ${givenMonth} and day ${givenDay}`;
    }
}

module.exports = {
    getPeopleData,
    getPersonById,
    sameStreet,
    manipulateSsn,
    sameBirthday
};
