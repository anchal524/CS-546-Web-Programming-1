const axios = require("axios");
const people = require("./people");
async function getStocksData() {
    let {data} = await axios.get(
        "https://gist.githubusercontent.com/graffixnyc/8c363d85e61863ac044097c0d199dbcc/raw/7d79752a9342ac97e4953bce23db0388a39642bf/stocks.json"
    );

    return data;
}

function validateStringParams(param, paramName) {
    if (!param) {
        throw `Error: No ${paramName} passed to the function`;
    } else if (typeof param !== "string") {
        throw `Type Error: Argument ${param} passed is not a string`;
    } else if (param.length === 0) {
        throw `Error: No element present in string ${paramName}`;
    } else if (!param.trim()) {
        throw `Error: Empty spaces passed to string ${paramName}`;
    }
}
async function listShareholders() {
    let len = arguments.length;
    if (len > 0) {
        throw `Error: listShareholders does not accept arguments`;
    }
    const peopleData = await people.getPeopleData();
    const stockData = await getStocksData();
    let resultShare = [];
    for (let stock of stockData) {
        let shareholder = stock["shareholders"];
        for (let holder of shareholder) {
            let searchId = holder["userId"].trim();
            for (let pd of peopleData) {
                if (pd["id"] === searchId) {
                    holder["first_name"] = pd["first_name"];
                    holder["last_name"] = pd["last_name"];
                    delete holder["userId"];
                    break;
                }
            }
        }
        resultShare.push(stock);
    }
    return resultShare;
}

async function topShareholder(givenStock) {
    validateStringParams(givenStock, "stock name");
    const stockData = await getStocksData();
    givenStock = givenStock.trim();
    let maxShares = 0;
    let maxHolderId = "";
    for (let stock of stockData) {
        if (stock["stock_name"] === givenStock) {
            if (stock["shareholders"].length === 0) {
                return `${givenStock} currently has no shareholders.`;
            }
            let maxShareResult = gettingMaxShare(stock["shareholders"]);
            maxShares = maxShareResult[0];
            maxHolderId = maxShareResult[1];
            break;
        }
    }
    if (!maxHolderId) {
        throw `Error : No Stock with name ${givenStock} `;
    }
    const holderName = await people.getPersonById(maxHolderId);
    let name = holderName["first_name"] + " " + holderName["last_name"];
    return `With ${maxShares} shares in ${givenStock}, ${name} is the top shareholder.`;
}

function gettingMaxShare(shareHolderList) {
    let maxShares = shareHolderList[0]["number_of_shares"];
    let maxShareId = shareHolderList[0]["userId"];
    for (let sh of shareHolderList) {
        if (sh["number_of_shares"] > maxShares) {
            maxShares = sh["number_of_shares"];
            maxShareId = sh["userId"];
        }
    }
    return [maxShares, maxShareId];
}
async function listStocks(givenFirstName, givenLastName) {
    validateStringParams(givenFirstName, "first name");
    validateStringParams(givenLastName, "last name");
    givenFirstName = givenFirstName.trim();
    givenLastName = givenLastName.trim();
    const peopleData = await people.getPeopleData();
    const stockData = await getStocksData();
    let personId = getIdbyName(givenFirstName, givenLastName, peopleData);
    if (!personId) {
        throw `Error: ${givenFirstName} ${givenLastName} does not exist in the people data`;
    }
    let result = getStockCount(personId, stockData);
    if (result.length === 0) {
        throw `Error: ${givenFirstName} ${givenLastName} does not own shares in any of the companies`;
    }
    return result;
}

function getIdbyName(fName, lName, peopleData) {
    for (let pd of peopleData) {
        if (pd["first_name"] === fName && pd["last_name"] === lName) {
            return pd["id"];
        }
    }
}

function getStockCount(id, stockData) {
    let stockresult = [];
    for (let stock of stockData) {
        let shareholderlist = stock["shareholders"];
        if (shareholderlist.length !== 0) {
            for (let holder of shareholderlist) {
                if (holder["userId"] === id) {
                    stockresult.push({
                        stock_name: stock["stock_name"],
                        number_of_shares: holder["number_of_shares"],
                    });
                }
            }
        }
    }
    return stockresult;
}
async function getStockById(searchId) {
    validateStringParams(searchId, "Stock Id");
    const stockData = await getStocksData();
    searchId = searchId.trim();
    for (let stock of stockData) {
        if (stock["id"] === searchId) {
            return stock;
        }
    }
    throw `Not Found Error : Id ${searchId} not found in stock data`;
}

module.exports = {listShareholders, topShareholder, listStocks, getStockById};
