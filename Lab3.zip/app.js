const people = require("./people");
const stock = require("./stocks");

async function main() {
    try {
        const peopledata = await people.getPeopleData();
        console.log(peopledata);
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await people.getPersonById());
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(
            await people.getPersonById("7989fa5e-8f3f-458d-ad58-23c8d9ef5a10")
        );
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await people.sameStreet("", ""));
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await people.sameStreet("sutherland", "point"));
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await people.manipulateSsn(12));
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(await people.manipulateSsn());
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(await people.sameBirthday(09, "25"));
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(await people.sameBirthday(13, 88));
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await stock.listShareholders());
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(await stock.listShareholders(88));
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await stock.topShareholder(""));
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(
            await stock.topShareholder("Nuveen Floating Rate Income Fund")
        );
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await stock.listStocks());
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(await stock.listStocks(" Fidel ", " Crutch "));
    } catch (e) {
        console.log(e);
    }

    try {
        console.log(await stock.getStockById("984938"));
    } catch (e) {
        console.log(e);
    }
    try {
        console.log(
            await stock.getStockById(" f652f797-7ca0-4382-befb-2ab8be914ff0 ")
        );
    } catch (e) {
        console.log(e);
    }
}

//call main
main();
