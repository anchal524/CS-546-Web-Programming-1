(function () {
    function palindromeChecker(text) {
        validateStringParams(text, "text");
        let textToBechecked = text.toLowerCase();
        textToBechecked = textToBechecked.replace(/[^0-9a-z]/gi, "");
        if (!textToBechecked.trim()) {
            throw `Error: No valid text passed`;
        }
        textToBecheckedReversed = textToBechecked.split("").reverse().join("");
        if (textToBechecked === textToBecheckedReversed) {
            return true;
        }

        return false;
    }

    function validateStringParams(param, paramName) {
        if (!param) {
            throw `Error: No ${paramName} passed `;
        } else if (typeof param !== "string") {
            throw `Type Error: Argument ${param} passed is not a string ${paramName}`;
        } else if (param.length === 0) {
            throw `Error: No element present in ${paramName}`;
        } else if (!param.trim()) {
            throw `Error: Empty spaces passed as ${paramName}`;
        }
    }

    const staticForm = document.getElementById("static-form");

    if (staticForm) {
        const phraseToBeChecked = document.getElementById("phrase");
        const errorContainer = document.getElementById("error-container");
        const errorTextElement =
            errorContainer.getElementsByClassName("text-goes-here")[0];
        let myList = document.getElementById("attempts");
        // let palindromeList = document.getElementById("is-palindrome");
        // let notPalindromeList = document.getElementById("not-palindrome");
        staticForm.addEventListener("submit", (event) => {
            event.preventDefault();

            try {
                const phraseToBeCheckedValue = phraseToBeChecked.value;

                const result = palindromeChecker(phraseToBeCheckedValue);
                let li = document.createElement("li");
                li.innerHTML = phraseToBeCheckedValue;
                myList.appendChild(li);
                if (result) {
                    li.className = "is-palindrome";
                } else {
                    li.className = "not-palindrome";
                }
            } catch (e) {
                const message = typeof e === "string" ? e : e.message;
                errorTextElement.textContent = e;
            }
        });
    }
})();
