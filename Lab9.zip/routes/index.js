const path = require("path");

const constructorMethod = (app) => {
    app.get("^/$", (req, res) => {
        res.sendFile(path.resolve("static/about.html"));
    });

    app.use("*", (req, res) => {
        res.status(404).json({status: 404, error: "Not Found"});
    });
};

module.exports = constructorMethod;
